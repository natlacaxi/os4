Tests `security_tests` : a completer. Lancer la suite via `make test`.
